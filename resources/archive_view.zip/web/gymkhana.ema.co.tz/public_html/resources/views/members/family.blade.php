<h5 class="fs-title mb-4">
    Dependants Information
</h5>

<label class="pay">Spouse’s full
    name(If to be
    included in the
    membership)*</label>
<input type="text" name="spouse_name" placeholder="Spouse’s full name" class="form-control mb-3" />
<label class="pay">Names of
    children: (Under 18
    years of age may be included
    in the
    membership)*</label>


<hr>


<button type="button" name="add" class="btn btn-success btn-xs add"><i class="fas fa-plus">
        add
        Childrens</i></button><br>
<br>
<div class="table-responsive">
    <table class="table table-bordered" id="cart">
        <thead>
            <tr>
                <th>CHIDREN NAME
                </th>
                <th>DATE OF
                    BIRTH</th>

                <th>Action</th>
            </tr>
        </thead>
        <tbody>


        </tbody>

    </table>
</div>