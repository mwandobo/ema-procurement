<ul class="navbar-item theme-brand flex-row  text-center">
    <li class="nav-item theme-logo">
        <a href="{{ url('/') }}">
            <img src="{{ url('assets/img/logo.jpg') }}" class="navbar-logo" alt="logo">
        </a>
    </li>
    <li class="nav-item theme-text">
        <a href="{{ url('/') }}" class="nav-link"> Gymkhana </a>
    </li>
</ul>
