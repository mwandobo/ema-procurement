<!-- Copyright Footer Starts -->
<div class="footer-wrapper">
    <div class="footer-section f-section-1">
        <p class=""> {{ __('Copyright © '.date("Y").' Dar es salaam Gymkhana club. All rights reserved.')}} </p>

    </div>
    <div class="footer-section f-section-2">
        <p class=""> {{ __('Crafted with extra')}}  <i class="las la-heart text-danger"></i></p>
    </div>
</div>
<!-- Copyright Footer Ends -->
