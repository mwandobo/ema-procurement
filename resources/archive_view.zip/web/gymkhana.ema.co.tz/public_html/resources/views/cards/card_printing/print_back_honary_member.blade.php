<!DOCTYPE html>
<html>

<head>
    <title></title>
    <link href="{{asset('assets/css/all.css')}}" rel="stylesheet" type="text/css">
    <style>
    h5 {
        margin-top: 1em;
    }

    li {
        margin-bottom: 1em;
        margin-top: -1em;


        word-spacing: -1px;



    }


    b {

        text-color: black;

    }
    </style>
</head>

<body>

     <div class="row" style="width:635px;heigth:485px;padding-left:168px;padding-top:35px; border-radius:7px;  ">
        <div class="col">

            <div class="row " style="background-color: #008000; max-width: 500px;max-height: 50px;">
                <centre>
                    <h4 class="card-title"
                        style="color:white; font-size:17px; text-align: center; padding-left:18px; padding-top:7px;">
                        <b>CLUBS PARTICIPATING IN RECIPROCAL MEMBERSHIP
                            SCHEME</b>
                    </h4>
                    </centr>

            </div>

            <div class="row" style="line-height: 19px; background-color: #191970;">
                
                <div class="col-md-6 col-lg-6" style="margin-top: 1em; padding-right:3px; ">

                    <ol style="color:white;">
                        <li style="font-size:12px;brightness(0%);">
                            <p style="color:white;">Arusha
                                Gymkhana Club</p>
                        </li>
                        <li style="font-size:12px; text-color:#000000;">
                            <p style="color:white;">Bombay
                                Presidency Golf Club</p>
                        </li>
                        <li style="font-size:12px; text-color:#000000;">
                            <p style="color:white;">Kampala
                                Golf Club</p>
                        </li>
                        <li style="font-size:12px; text-color:#000000;">
                            <p style="color:white;">Kibene
                                Club</p>
                        </li>
                        <li style="font-size:12px; text-color:#000000;">
                            <p style="color:white;">Kitwe Golf
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Lilongwe Golf
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Limuru Country
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Lusaka Golf
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Mombasa Golf
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Mombasa Sports
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Moshi
                                Club</p>
                        </li>

                        <li style="font-size:12px;">
                            <p style="color:white;">Morogoro Gymkhana
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Entebbe Club</p>
                        </li>
                    </ol>

                </div>

                <div class="col-md-6 col-lg-6" style="margin-top: 1em; line-width: 15px;">

                    <ol start="13" style="color:white;">

                        <li style="font-size:12px;">
                            <p style="color:white;">Muthaiga Golf
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Ndola Golf
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Nyali Golf &
                                Country Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Mufindi
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Parklands
                                Sports Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Roan Antelope
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Royal Nairobi
                                Golf</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Sigona Golf
                                Club</p>
                        </li>
                        <li style="font-size:11.3px;">
                            <p style="color:white;">The Des Moines Embassy Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">The Lusaka
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Uganda Golf
                                Club</p>
                        </li>
                        <li style="font-size:12px;">
                            <p style="color:white;">Vet Lab Golf
                                Club</p>
                        </li>

                    </ol>

                </div>
                <!--
                <div class="col-md-2 col-lg-1.5" style="margin-top: 1em;">
                <p style="padding-top:50px;">
                        {!! QrCode::size(50)->generate($card); !!}
</p>

                </div>
                -->
            </div>



        </div>
    </div>

    <br><br>
    <button onclick="window.print()">Click here to print</button>

</body>

</html>