<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Member\Member;
use App\Models\Accounting\JournalEntry;
use App\Models\Accounting\Deposit;
use App\Models\Accounting\Expenses;
use App\Models\User;
use App\Models\Payroll\SalaryPayment;
use App\Models\restaurant\Order;
use App\Models\Facility\Invoice;
use DateTime;
use DB;


use App\Models\Bar\Bar;

class ReportController extends Controller
{
    
}
