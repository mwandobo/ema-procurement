<?php

namespace App\Http\Controllers;

use App\Models\Mandotory;
use Illuminate\Http\Request;

class MandotoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Mandotory  $mandotory
     * @return \Illuminate\Http\Response
     */
    public function show(Mandotory $mandotory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Mandotory  $mandotory
     * @return \Illuminate\Http\Response
     */
    public function edit(Mandotory $mandotory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Mandotory  $mandotory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Mandotory $mandotory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Mandotory  $mandotory
     * @return \Illuminate\Http\Response
     */
    public function destroy(Mandotory $mandotory)
    {
        //
    }
}
