<?php

namespace App\Models\restaurant;

use Illuminate\Database\Eloquent\Model;

class Balance extends BaseModel
{
  
}
