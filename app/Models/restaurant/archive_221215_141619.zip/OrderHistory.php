<?php

namespace App\Models\restaurant;

use Illuminate\Database\Eloquent\Model;

class OrderHistory extends Model
{
    protected $table = 'order_history';
    protected $guarded     = ['id','_token'];
   
}
